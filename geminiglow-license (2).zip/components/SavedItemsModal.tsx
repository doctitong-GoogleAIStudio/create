import React, { useState } from 'react';
import type { SavedAnalysis, SavedProduct, Product } from '../types';
import { SavedAnalysisCard } from './SavedAnalysisCard';
import { SavedLookCard } from './SavedLookCard';

interface SavedItemsModalProps {
  savedAnalyses: SavedAnalysis[];
  savedProducts: SavedProduct[];
  ratings: { [key: string]: number };
  onRateProduct: (product: Product, rating: number) => void;
  onDeleteAnalysis: (id: string) => void;
  onDeleteProduct: (id: string) => void;
  onClose: () => void;
}

export const SavedItemsModal: React.FC<SavedItemsModalProps> = ({
  savedAnalyses,
  savedProducts,
  ratings,
  onRateProduct,
  onDeleteAnalysis,
  onDeleteProduct,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'analyses' | 'looks'>('analyses');

  const TabButton: React.FC<{
    label: string;
    count: number;
    tabName: 'analyses' | 'looks';
  }> = ({ label, count, tabName }) => (
    <button
      onClick={() => setActiveTab(tabName)}
      className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${
        activeTab === tabName
          ? 'bg-[#c5a78f] text-white'
          : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
      }`}
    >
      {label} <span className="text-xs bg-black/10 dark:bg-white/10 px-1.5 py-0.5 rounded-full">{count}</span>
    </button>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4 animate-fade-in" onClick={onClose}>
      <div
        className="bg-white dark:bg-gray-800 p-6 sm:p-8 rounded-2xl shadow-2xl max-w-4xl w-full relative max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-2 right-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 text-3xl font-bold z-10"
        >
          &times;
        </button>
        <h2 className="text-2xl font-bold text-[#3a3a3a] dark:text-gray-100 mb-4">My Saved Items</h2>
        
        <div className="border-b border-gray-200 dark:border-gray-700 mb-4">
          <div className="flex items-center gap-2">
            <TabButton label="Saved Analyses" count={savedAnalyses.length} tabName="analyses" />
            <TabButton label="Saved Looks" count={savedProducts.length} tabName="looks" />
          </div>
        </div>

        <div className="overflow-y-auto flex-grow pr-2 -mr-2">
          {activeTab === 'analyses' && (
            <div className="space-y-4">
              {savedAnalyses.length > 0 ? (
                savedAnalyses.map((analysis) => (
                  <SavedAnalysisCard key={analysis.id} analysis={analysis} onDelete={onDeleteAnalysis} />
                ))
              ) : (
                <p className="text-center text-gray-500 dark:text-gray-400 py-8">You haven't saved any skin analyses yet.</p>
              )}
            </div>
          )}

          {activeTab === 'looks' && (
            <div className="space-y-4">
              {savedProducts.length > 0 ? (
                savedProducts.map((product) => (
                  <SavedLookCard key={product.id} product={product} onDelete={onDeleteProduct} ratings={ratings} onRateProduct={onRateProduct} />
                ))
              ) : (
                <p className="text-center text-gray-500 dark:text-gray-400 py-8">You haven't saved any product looks yet.</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};