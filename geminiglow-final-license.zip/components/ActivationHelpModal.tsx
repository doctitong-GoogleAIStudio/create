import React from 'react';

interface ActivationHelpModalProps {
  onClose: () => void;
}

export const ActivationHelpModal: React.FC<ActivationHelpModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 z-50 flex justify-center items-center p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-2xl max-w-lg w-full relative max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-2 right-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 text-3xl font-bold">&times;</button>
        <h2 className="text-2xl font-bold text-[#3a3a3a] dark:text-gray-100 mb-6 text-center">How to Activate Your App</h2>
        
        <div className="space-y-4 text-left text-gray-600 dark:text-gray-300">
          <ol className="list-decimal list-inside space-y-3">
            <li>On the previous screen, copy your unique "Installation ID" and "Public Key".</li>
            <li>
              Send both the ID and Key in an email to{' '}
              <a href="mailto:vicvicventures@gmail.com" className="text-[#c5a78f] hover:underline font-semibold">
                vicvicventures@gmail.com
              </a>{' '}
              to request payment details.
            </li>
            <li>You will receive a reply with a GCash QR code or number to complete the 1,500 PHP payment.</li>
            <li>After paying, reply to the email with a screenshot of your GCash receipt as proof of payment.</li>
            <li>Once your payment is verified, your unique "License Key" will be sent to you via email.</li>
            <li>Return to the app, paste the complete License Key into the text box, and click "Activate".</li>
            <li>The app will now be unlocked and ready to use on this device.</li>
          </ol>
          <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
            <h3 className="font-bold text-lg text-gray-800 dark:text-gray-100">Important Notes:</h3>
            <ul className="list-disc list-inside mt-2 text-sm space-y-1">
              <li>Each license key is tied to one specific device. It will not work on other devices.</li>
              <li>Please copy the ID and Key carefully. Any mistake will result in an invalid license.</li>
            </ul>
          </div>
        </div>
        
        <button
          onClick={onClose}
          className="mt-8 w-full bg-[#c5a78f] text-white font-bold py-3 px-4 rounded-xl hover:bg-[#b9987e] transition-all duration-300 text-lg shadow-md hover:shadow-lg"
        >
          Close
        </button>
      </div>
    </div>
  );
};