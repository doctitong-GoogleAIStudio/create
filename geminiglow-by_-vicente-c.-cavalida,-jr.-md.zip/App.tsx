import React, { useState, useEffect, useCallback } from 'react';
import { ImageUploader } from './components/ImageUploader';
import { ImageCropper } from './components/ImageCropper';
import { RecommendationCard } from './components/RecommendationCard';
import { ErrorMessage } from './components/ErrorMessage';
import { Loader } from './components/Loader';
import { getMakeupRecommendations, generateAfterImage } from './services/geminiService';
import { base64ToDataUrl } from './services/imageProcessingService';
import type { MakeupRecommendation, Product, ProductRecommendation, SavedAnalysis, SavedProduct, UserProfile } from './types';
import { TutorialOverlay } from './components/TutorialOverlay';
import { UserProfile as UserProfileModal } from './components/UserProfile';
import { SunIcon } from './components/icons/SunIcon';
import { MoonIcon } from './components/icons/MoonIcon';
import { UserIcon } from './components/icons/UserIcon';
import { RestartIcon } from './components/icons/RestartIcon';
import { BookmarkIcon } from './components/icons/BookmarkIcon';
import { SavedItemsModal } from './components/SavedItemsModal';
import { InfoIcon } from './components/icons/InfoIcon';

type AppState = 'upload' | 'crop' | 'loading' | 'results' | 'error';

const getProductKey = (product: Product): string => {
  return `${product.brand}-${product.name}`.toLowerCase().replace(/\s+/g, '-');
};

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>('upload');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [croppedImage, setCroppedImage] = useState<{ base64: string; mimeType: string; url: string } | null>(null);
  const [recommendations, setRecommendations] = useState<MakeupRecommendation | null>(null);
  const [afterImageUrl, setAfterImageUrl] = useState<string | null>(null);
  const [isGeneratingAfterImage, setIsGeneratingAfterImage] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // UI State
  const [showTutorial, setShowTutorial] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showSavedItemsModal, setShowSavedItemsModal] = useState(false);

  // User Data State
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const savedProfile = localStorage.getItem('userProfile');
      return savedProfile ? JSON.parse(savedProfile) : { name: '', style: 'Natural', concerns: [], finish: 'Satin', priorities: [], avoidances: [] };
    } catch (e) {
      return { name: '', style: 'Natural', concerns: [], finish: 'Satin', priorities: [], avoidances: [] };
    }
  });

  const [savedAnalyses, setSavedAnalyses] = useState<SavedAnalysis[]>(() => {
    try {
        const saved = localStorage.getItem('savedAnalyses');
        return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });

  const [savedProducts, setSavedProducts] = useState<SavedProduct[]>(() => {
    try {
      const saved = localStorage.getItem('savedProducts');
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });

  const [productRatings, setProductRatings] = useState<{ [key: string]: number }>(() => {
    try {
      const saved = localStorage.getItem('productRatings');
      return saved ? JSON.parse(saved) : {};
    } catch (e) { return {}; }
  });


  useEffect(() => {
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    setIsDarkMode(prefersDark);
  }, []);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    localStorage.setItem('userProfile', JSON.stringify(userProfile));
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem('savedAnalyses', JSON.stringify(savedAnalyses));
  }, [savedAnalyses]);
  
  useEffect(() => {
    localStorage.setItem('savedProducts', JSON.stringify(savedProducts));
  }, [savedProducts]);

  useEffect(() => {
    localStorage.setItem('productRatings', JSON.stringify(productRatings));
  }, [productRatings]);


  const handleImageChange = (file: File) => {
    setImageFile(file);
    setImageUrl(URL.createObjectURL(file));
    setAppState('crop');
    setError(null);
  };

  const handleAnalyze = useCallback(async (base64: string, mimeType: string) => {
    setAppState('loading');
    setCroppedImage({ base64, mimeType, url: base64ToDataUrl(base64, mimeType) });
    setAfterImageUrl(null);

    try {
      const result = await getMakeupRecommendations(base64, mimeType, userProfile);
      setRecommendations(result);
      setAppState('results');

      // Kick off after-image generation in the background
      setIsGeneratingAfterImage(true);
      generateAfterImage(base64, mimeType, result)
        .then(afterImageBase64 => {
          setAfterImageUrl(base64ToDataUrl(afterImageBase64, mimeType));
        })
        .catch(e => {
          console.error("Failed to generate after image:", e);
          // Don't show an error, just fail gracefully
        })
        .finally(() => {
          setIsGeneratingAfterImage(false);
        });

    } catch (err: any) {
      setError(err.message || 'An unknown error occurred.');
      setAppState('error');
    }
  }, [userProfile]);

  const handleReset = () => {
    setAppState('upload');
    setImageFile(null);
    setImageUrl(null);
    setCroppedImage(null);
    setRecommendations(null);
    setAfterImageUrl(null);
    setError(null);
  };
  
  const handleRateProduct = (product: Product, rating: number) => {
    const key = getProductKey(product);
    setProductRatings(prev => ({...prev, [key]: rating}));
  }

  const handleSaveAnalysis = () => {
    if (!recommendations || !croppedImage) return;
    const newSavedAnalysis: SavedAnalysis = {
        id: new Date().toISOString(),
        imageUrl: croppedImage.url,
        skinAnalysis: recommendations.skinAnalysis,
    };
    setSavedAnalyses(prev => [newSavedAnalysis, ...prev]);
    alert("Skin analysis saved!");
  }

  const handleDeleteAnalysis = (id: string) => {
    setSavedAnalyses(prev => prev.filter(a => a.id !== id));
  }

  const handleSaveProduct = (productRec: ProductRecommendation) => {
    const newSavedProduct: SavedProduct = {
      ...productRec,
      id: `${productRec.category}-${new Date().toISOString()}`
    };
    setSavedProducts(prev => [newSavedProduct, ...prev]);
    alert(`${productRec.category} look saved!`);
  }

  const handleDeleteProduct = (id: string) => {
    setSavedProducts(prev => prev.filter(p => p.id !== id));
  }

  const renderContent = () => {
    switch (appState) {
      case 'upload':
        return <ImageUploader onImageChange={handleImageChange} />;
      case 'crop':
        if (imageUrl && imageFile) {
          return <ImageCropper imageUrl={imageUrl} imageFile={imageFile} onAnalyze={handleAnalyze} onCancel={handleReset} />;
        }
        return null;
      case 'loading':
        return (
          <div className="text-center p-8">
            <Loader size="lg" />
            <h2 className="mt-6 text-xl font-semibold text-gray-700 dark:text-gray-200">Analyzing Your Photo...</h2>
            <p className="text-gray-500 dark:text-gray-400">Our AI is finding your perfect match. This might take a moment.</p>
          </div>
        );
      case 'results':
        if (recommendations && croppedImage) {
          return (
            <RecommendationCard 
              recommendations={recommendations} 
              beforeImageUrl={croppedImage.url}
              afterImageUrl={afterImageUrl}
              isGeneratingAfterImage={isGeneratingAfterImage}
              ratings={productRatings}
              onRateProduct={handleRateProduct}
              onSaveAnalysis={handleSaveAnalysis}
              onSaveProduct={handleSaveProduct}
            />
          );
        }
        return null;
      case 'error':
        return <ErrorMessage message={error || 'An unexpected error occurred.'} />;
      default:
        return null;
    }
  };

  return (
    <>
      {showTutorial && <TutorialOverlay onDismiss={() => setShowTutorial(false)} />}
      {showProfileModal && <UserProfileModal profile={userProfile} onSave={setUserProfile} onClose={() => setShowProfileModal(false)} />}
      {showSavedItemsModal && <SavedItemsModal 
          savedAnalyses={savedAnalyses}
          savedProducts={savedProducts}
          ratings={productRatings}
          onRateProduct={handleRateProduct}
          onDeleteAnalysis={handleDeleteAnalysis}
          onDeleteProduct={handleDeleteProduct}
          onClose={() => setShowSavedItemsModal(false)}
      />}

      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-100 font-sans transition-colors duration-300">
        <header className="py-4 px-4 sm:px-8 border-b border-gray-200 dark:border-gray-700 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm sticky top-0 z-40">
            <div className="max-w-5xl mx-auto flex justify-between items-center">
                <h1 className="text-2xl font-bold text-[#c5a78f]">
                    Gemini<span className="text-gray-600 dark:text-gray-300">Glow</span>
                </h1>
                <div className="flex items-center gap-2 sm:gap-4">
                  {appState === 'results' || appState === 'error' ? (
                      <button onClick={handleReset} className="font-semibold py-2 px-3 rounded-lg transition-colors bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600 flex items-center gap-2" title="Start Over">
                          <RestartIcon className="w-4 h-4" />
                          <span className="hidden sm:inline">Start Over</span>
                      </button>
                  ) : null}
                  <button onClick={() => setShowTutorial(true)} className="text-gray-500 dark:text-gray-400 hover:text-[#c5a78f] dark:hover:text-[#c5a78f] p-2 rounded-full" title="About & How It Works">
                     <InfoIcon className="w-5 h-5" />
                  </button>
                  <button onClick={() => setShowSavedItemsModal(true)} className="text-gray-500 dark:text-gray-400 hover:text-[#c5a78f] dark:hover:text-[#c5a78f] p-2 rounded-full" title="My Saved Items">
                      <BookmarkIcon className="w-5 h-5" />
                  </button>
                  <button onClick={() => setShowProfileModal(true)} className="text-gray-500 dark:text-gray-400 hover:text-[#c5a78f] dark:hover:text-[#c5a78f] p-2 rounded-full" title="My Profile">
                      <UserIcon className="w-5 h-5" />
                  </button>
                  <button onClick={() => setIsDarkMode(!isDarkMode)} className="text-gray-500 dark:text-gray-400 hover:text-[#c5a78f] dark:hover:text-[#c5a78f] p-2 rounded-full" title="Toggle Theme">
                      {isDarkMode ? <SunIcon /> : <MoonIcon />}
                  </button>
                </div>
            </div>
        </header>

        <main className="max-w-5xl mx-auto p-4 sm:p-8">
            {renderContent()}
        </main>
        
        <footer className="text-center py-6 text-xs text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-gray-700 mt-8">
          <p>Powered by Google Gemini. Recommendations are AI-generated and may not be perfect. Always patch test new products.</p>
          <p>&copy; {new Date().getFullYear()} GeminiGlow. All rights reserved.</p>
        </footer>
      </div>
    </>
  );
};

export default App;